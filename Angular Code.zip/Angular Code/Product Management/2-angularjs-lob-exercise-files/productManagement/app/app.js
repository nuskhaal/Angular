
(function () {
    "use strict";
    var app = angular.module("productManagement",[]);
}());